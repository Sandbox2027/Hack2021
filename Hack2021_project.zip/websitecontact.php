<?php
$insert = false;
if(isset($_POST['name'])){
    // Set connection variables
    $server = "localhost";
    $username = "root";
    $password = "";

    // Create a database connection
    $con = mysqli_connect($server, $username, $password);

    // Check for connection success
    if(!$con){

        die("connection to this database failed due to" . mysqli_connect_error());
    }

    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $desc = $_POST['desc'];
    $sql = "INSERT INTO `trip`.`trip` (`name`, `age`, `gender`, `email`, `phone`, `other`, `dt`) VALUES ('$name', '$age', '$gender', '$email', '$phone', '$desc', current_timestamp());";

    if($con->query($sql) == true){
 
        $insert = true;
    }
    else{
        echo "ERROR: $sql <br> $con->error";
    }

    // Closing the database connection
    $con->close();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="websitestyle.css">
        <title>Contact Us</title>
    <link rel="icon" href="icon.png" type="image/png">
    </head>
    <img class ="bg" src="plan.jpg" alt="hello">
     <h1 style="text-align: center; font-size: 90px; bottom:19px;  color: brown; ">Customer Service</h1>
    <body id="contact">
        <div class="container">
            

            <nav class="menu">
                <a href="websiteindex.html">Home</a> &nbsp; &nbsp;
                <a href="websiteabout.html">Choose Your Plan</a> &nbsp; &nbsp;
                <a href="websitecontact.php">Contact Us</a> &nbsp; &nbsp;

            </nav>

            <aside>
                <img src="icon.png" alt="icon image" width="115" height="90" >
            </aside>

            <article class="main">
                <div id="form"><!--Values taken in this form are saved in the database(mysql)-->
                    <form action="websitecontact.php" method="POST">
                        <p>
                        <label for="Name">Name:</label>
                        <input type="text" name="name" id="name"  >
                        </p>
                       <p> 
                       <label for="Name">Age:</label>
                       <input type="text" name="age" id="age" ></p>
          <p>  
          <label for="Name">Gender:</label>
          <input type="text" name="gender" id="gender" ></p>
                        <p>
                        <label for="Name">Phone Number:</label>
                        <input type="number" name="phone" id="phone" ></p>
                        
                        <P>
                        <label for="Name">Emailid:</label>
                        <input type="email" name="email" id="email" >
                    </P>
                
                    <p>
                        <label for="Name">Message</label>
                        <br>
                        
                    
                    
            <textarea name="desc" id="desc" cols="30" rows="10" placeholder="Enter any other required information"></textarea>
                    
                        <input type="submit" name="submit" value="SUBMIT" id="submit">
                    </p>
                    </form>
                    
                </div>
                </article>

                <footer>
                     &copy; 2021 TRASI website &nbsp; Designed by SandBox  &nbsp;
                Contact Us On <a href="mailto:worksn2027@gmail.com?suject=hello">worksn2027@gmail.com</a>

    
                </footer>
                
            </div>
        </body>
    </html>